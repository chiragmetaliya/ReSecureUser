import 'dart:io';
import 'dart:math';
import 'package:camera/camera.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
// import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

class CameraViewPage extends StatefulWidget {
  const CameraViewPage({super.key});

  @override
  State<CameraViewPage> createState() => _CameraViewPageState();
}

class _CameraViewPageState extends State<CameraViewPage> {
  bool _isBackCamera = true;
  bool _isMotionDetectionOn = false;
  CameraController? _cameraController;
  List<CameraDescription>? _cameras;
  final _random = Random();
  String? _deviceIdentifier;
  bool _isConnected = true;
  bool _isActive = true;

  @override
  void initState() {
    super.initState();
    _initializeCamera();
    _getDeviceIdentifier();
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    super.dispose();
  }

  Future<void> _initializeCamera() async {
    _cameras = await availableCameras();
    _setCameraController(
        _isBackCamera ? CameraLensDirection.back : CameraLensDirection.front);
  }

  Future<void> _setCameraController(CameraLensDirection direction) async {
    final selectedCamera =
        _cameras?.firstWhere((camera) => camera.lensDirection == direction);
    if (selectedCamera != null) {
      _cameraController =
          CameraController(selectedCamera, ResolutionPreset.high);

      try {
        await _cameraController?.initialize();
        setState(() {});
      } catch (e) {
        print('Error initializing camera: $e');
      }
    }
  }

  Future<void> _loadCameraData(String deviceIdentifier) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final cameraRef = FirebaseDatabase.instance
          .ref()
          .child('cameras')
          .child(user.uid)
          .child(deviceIdentifier);
      final cameraSnapshot = await cameraRef.once(DatabaseEventType.value);

      if (cameraSnapshot.snapshot.value != null) {
        final cameraData =
            cameraSnapshot.snapshot.value as Map<dynamic, dynamic>;

        _isMotionDetectionOn = cameraData['motion_detection'] ?? false;
        _isBackCamera = cameraData['back_camera'] ?? true;

        _setCameraController(_isBackCamera
            ? CameraLensDirection.back
            : CameraLensDirection.front);
        final bool isActive = cameraData['is_active'] ?? true;
        setState(() {
          _isConnected = isActive;
          _isActive = isActive;
        });
      } else {
        _registerCamera(deviceIdentifier);
      }
    }
  }

  Future<void> _toggleMotionDetection() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final cameraRef = FirebaseDatabase.instance
          .ref()
          .child('cameras')
          .child(user.uid)
          .child(_deviceIdentifier!);
      await cameraRef.update({
        'motion_detection': _isMotionDetectionOn,
      });
    }
  }

  Future<void> _toggleCamera() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      _isBackCamera = !_isBackCamera;
      _setCameraController(
          _isBackCamera ? CameraLensDirection.back : CameraLensDirection.front);

      final cameraRef = FirebaseDatabase.instance
          .ref()
          .child('cameras')
          .child(user.uid)
          .child(_deviceIdentifier!);
      await cameraRef.update({
        'back_camera': _isBackCamera,
      });
    }
  }

  Future<void> _getDeviceIdentifier() async {
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    if (Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      _deviceIdentifier = androidInfo.androidId;
    } else if (Platform.isIOS) {
      IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
      _deviceIdentifier = iosInfo.identifierForVendor;
    }

    if (_deviceIdentifier != null) {
      _loadCameraData(_deviceIdentifier!);
    }
  }

  Future<void> _registerCamera(String deviceIdentifier) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final cameraRef = FirebaseDatabase.instance
          .ref()
          .child('cameras')
          .child(user.uid)
          .child(deviceIdentifier);

      await cameraRef.set({
        'id': cameraRef.key,
        'name': 'Camera ${_random.nextInt(1000)}',
        'motion_detection': false,
        'back_camera': true,
        'camera_code': _random.nextInt(900000) + 100000,
        'is_active': true,
        'device_identifier': deviceIdentifier,
      });

      _loadCameraData(deviceIdentifier);
    }
  }

  Future<void> _toggleCameraStatus() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null && _deviceIdentifier != null) {
      final cameraRef = FirebaseDatabase.instance
          .ref()
          .child('cameras')
          .child(user.uid)
          .child(_deviceIdentifier!);

      final newStatus = !_isActive;
      await cameraRef.update({
        'is_active': newStatus,
      });

      setState(() {
        _isActive = newStatus;
        _isConnected = newStatus;
      });
    }
  }

  Widget _buildCameraPreview() {
    if (_cameraController == null || !_cameraController!.value.isInitialized) {
      return const Center(child: CircularProgressIndicator());
    } else {
      return AspectRatio(
        aspectRatio: _cameraController!.value.aspectRatio,
        child: CameraPreview(_cameraController!),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: const Color(0xFF2C3E50),
        title: const Text(
          'ReSecure',
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(5.0),
        child: Column(
          children: [
            Row(
              children: [
                Switch(
                  value: _isActive,
                  onChanged: (value) {
                    _toggleCameraStatus();
                  },
                ),
                Text(
                  _isActive ? 'On' : 'Off',
                  style: TextStyle(
                    color: _isActive ? Colors.green : Colors.red,
                    fontSize: 12,
                  ),
                ),
                const Spacer(),
                Container(
                  width: 20.0,
                  height: 20.0,
                  decoration: BoxDecoration(
                    color: _isConnected ? Colors.green : Colors.red,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 4.0),
                Text(
                  _isConnected ? 'Connected' : 'Disconnected',
                  style: TextStyle(
                    color: _isConnected ? Colors.green : Colors.red,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8.0),
            Expanded(
              child: SizedBox(
                width: double.infinity,
                child: _buildCameraPreview(),
              ),
            ),
            const SizedBox(height: 8.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  children: [
                    IconButton(
                      icon: Icon(
                        Icons.switch_camera,
                        color: _isBackCamera ? Colors.green : Colors.red,
                        size: 25,
                      ),
                      onPressed: () {
                        setState(() {
                          _toggleCamera();
                        });
                      },
                    ),
                    Text(
                      'Switch Camera',
                      style: TextStyle(
                        color: _isBackCamera ? Colors.green : Colors.red,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    IconButton(
                      icon: Icon(
                        Icons.motion_photos_on,
                        color: _isMotionDetectionOn ? Colors.green : Colors.red,
                        size: 25,
                      ),
                      onPressed: () {
                        setState(() {
                          _isMotionDetectionOn = !_isMotionDetectionOn;
                          _toggleMotionDetection();
                        });
                      },
                    ),
                    Text(
                      'Motion Detection',
                      style: TextStyle(
                        color: _isMotionDetectionOn ? Colors.green : Colors.red,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
