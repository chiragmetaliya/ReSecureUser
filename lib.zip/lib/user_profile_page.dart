import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  final String userName; // Pass the logged-in user's name here

  const ProfileScreen({Key? key, required this.userName}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 50,
              // Placeholder image or user's profile image here
              backgroundColor: Colors.grey,
            ),
            SizedBox(height: 20),
            Text(
              userName,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Divider(),
            TextButton(
              onPressed: () {
                // Navigate to change password screen or implement logic
              },
              child: Text('Change password'),
            ),
            Divider(),
            TextButton(
              onPressed: () {
                // Navigate to help screen or implement logic
              },
              child: Text('Help'),
            ),
            Divider(),
            TextButton(
              onPressed: () {
                // Implement logout functionality
              },
              child: Text('Logout'),
            ),
          ],
        ),
      ),
    );
  }
}
