import 'package:flutter/material.dart';

class AddViewer extends StatefulWidget {
  const AddViewer({super.key});

  @override
  State<AddViewer> createState() => _AddViewerState();
}

class _AddViewerState extends State<AddViewer> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF2C3E50),
        title: const Text(
          'ReSecure',
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: const Text("Add Viewer Page"),
    );
  }
}
